package com.example.bms;

import java.sql.Date;

public class Purchase {
}
