package com.example.bms;

public class getData {
    public static String username;
    public static String path;


}
