package com.example.bms;

public class Purchase {
}
